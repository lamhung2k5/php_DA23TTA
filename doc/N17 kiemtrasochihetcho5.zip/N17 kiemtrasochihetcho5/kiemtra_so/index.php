<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kiểm tra chia hết cho 5</title>
    <style>
       
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0f2f5;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .card {
            background-color: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.1);
            text-align: center;
            width: 350px;
        }
        h2 {
            color: #333;
            margin-top: 0;
        }
        input[type="number"] {
            width: calc(100% - 24px);
            padding: 12px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 16px;
        }
        button {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
            transition: 0.3s;
            width: 100%;
        }
        button:hover {
            background-color: #0056b3;
        }
        /* CSS trang trí hộp kết quả */
        .ket-qua {
            margin-top: 25px;
            padding: 15px;
            border-radius: 6px;
            font-size: 18px;
            font-weight: bold;
            display: inline-block;
            width: 100%;
            box-sizing: border-box;
        }
        .thanh-cong {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .that-bai {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
    </style>
</head>
<body>

<div class="card">
    <h2>Kiểm Tra Số</h2>
    <!-- Form nhập dữ liệu -->
    <form method="post" action="">
        <input type="number" name="so_nhap_vao" placeholder="Nhập một số nguyên..." required>
        <button type="submit" name="btn_kiemtra">Kiểm tra ngay</button>
    </form>

    <?php
    
    function kiemTraChiaHetCho5($so) {
        // Sử dụng phép chia lấy phần dư (%)
        if ($so % 5 == 0) {
            return true;
        } else {
            return false;
        }
    }

    
    if (isset($_POST['btn_kiemtra'])) {
        // Lấy giá trị số từ form nhập vào
        $so_kiem_tra = $_POST['so_nhap_vao'];

        
        if (kiemTraChiaHetCho5($so_kiem_tra)) {
            echo "<div class='ket-qua thanh-cong'> Số $so_kiem_tra <b>chia hết</b> cho 5.</div>";
        } else {
            echo "<div class='ket-qua that-bai'>❌ Số $so_kiem_tra <b>không chia hết</b> cho 5.</div>";
        }
    }
    ?>
</div>

</body>
</html>