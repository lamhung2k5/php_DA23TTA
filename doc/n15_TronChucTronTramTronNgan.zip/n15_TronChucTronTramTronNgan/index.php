<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form name="frmNhap" action="alg.php" method="post">
        <table align="center">
        <tr>
            <td>Nhập số n: </td>
            <td><input type="number" name="txtNhap" id=""></td>
        </tr>
        
        <tr>
            <td><input type="submit" name="sbmXem" value="Xem KQ" /></td>
            <td><input type="reset" name="rsHuy" value="Hủy bỏ" /></td>
        </tr>
        </table>
    </form>
</body>
</html>